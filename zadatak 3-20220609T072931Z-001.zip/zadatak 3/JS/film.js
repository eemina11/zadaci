$(document).ready(function(){
 
    $('#btn').click(function () {
 
        $('.sadrzaj').animate({
 
            "width":"500px",
 
            "height":"300px"
 
        }, 2000);
 
    });
 
});