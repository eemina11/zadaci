$(document).ready(function () {
    $('.sadrzaj').delay(2000).slideDown(1000);
    $('.close').on('click', function () {
        $('.sadrzaj').slideUp(1000);
    });
});
